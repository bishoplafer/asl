<div class="container">
	<h1>Tasks</h1>
	<p>Welcome <b><?php echo $user; ?></b>, you have been succesfully logged in!</p>
	<?php
		echo anchor('Logout', 'Logout');
	?>
</div>